import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.io.*;
import javax.sound.sampled.*;
import java.awt.Color;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
//
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
//ww  w  .  j av a2s  . com
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
//
public class Game extends JPanel implements Runnable {
  private Thread thread;
  private boolean running;
  private boolean pause = false;
  private Graphics gr;
  private int screenx = 312;
  private int screeny = 598;
  private Image screen;
  private ImageIcon bg;
// ========================================================
//    Variable
// ========================================================
  private Color[][] wall;
  private int rotation;
	private ArrayList<Integer> nextPieces = new ArrayList<Integer>();
	private Point pieceOrigin;
	private int currentPiece;
  private Block block;
  private int sizeByPieceX = 25;
  private int sizeByPieceY = 25;
  private int dir;
  private char step = 1;
  private int curPosX;
  private int curPosY;
  private char[][] mapMove = new char[23][12];
  private int score = 0;
  private int type;
  private Random rand = new Random();
  private List<Integer> check = new ArrayList<Integer>();
// ========================================================
//    Constructure
// ========================================================
  public Game() {
      init();
  } // Game()
// ========================================================
//    init
// ========================================================
  public void init() {
    setPreferredSize(new Dimension(screenx, screeny));
    addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent evt) {
        formKeyPressed(evt);
      }
    });
    running = true;
    // bg = new ImageIcon("bgscene.png");
    bg = new ImageIcon("background.gif");
    thread = new Thread(this);
    thread.setPriority(Thread.MIN_PRIORITY+1);
    thread.start();
    newPiece();
    loadMap();
  } // init()
// ========================================================
//    Load Wall
// ========================================================
  private void loadWall(Graphics g){
    wall = new Color[12][24];

    // If Want To See Edge Toogle Comment

  //   for (int i = 0; i < 12; i++) {
  //     for (int j = 0; j < 23; j++) {
  //       if (i == 0 || i== 11 || j == 22) {
  //         wall[i][j] = Color.GRAY;
  //       }
  //       else {
  //         wall[i][j] = Color.BLACK;
  //       }
  //     }
  //   }
  //   g.fillRect(0, 0, 26*12, 26*23);
  //   for (int i = 0; i < 12; i++) {
  //     for (int j = 0; j < 23; j++) {
  //       g.setColor(wall[i][j]);
  //       g.fillRect(26*i, 26*j, 25, 25);
  //     }
  //   }
  }

// ========================================================
//    Load Map
// ========================================================
  public void loadMap() {
    mapMove[0]  = "200000000002".toCharArray();
    mapMove[1]  = "200000000002".toCharArray();
    mapMove[2]  = "200000000002".toCharArray();
    mapMove[3]  = "200000000002".toCharArray();
    mapMove[4]  = "200000000002".toCharArray();
    mapMove[5]  = "200000000002".toCharArray();
    mapMove[6]  = "200000000002".toCharArray();
    mapMove[7]  = "200000000002".toCharArray();
    mapMove[8]  = "200000000002".toCharArray();
    mapMove[9]  = "200000000002".toCharArray();
    mapMove[10] = "200000000002".toCharArray();
    mapMove[11] = "200000000002".toCharArray();
    mapMove[12] = "200000000002".toCharArray();
    mapMove[13] = "200000000002".toCharArray();
    mapMove[14] = "200000000002".toCharArray();
    mapMove[15] = "200000000002".toCharArray();
    mapMove[16] = "200000000002".toCharArray();
    mapMove[17] = "200000000002".toCharArray();
    mapMove[18] = "200000000002".toCharArray();
    mapMove[19] = "200000000002".toCharArray();
    mapMove[20] = "200000000002".toCharArray();
    mapMove[21] = "200000000002".toCharArray();
    mapMove[22] = "222222222222".toCharArray();
  }
// ========================================================
//    New Piece
// ========================================================
	public void newPiece() {
		rotation = 0;
    curPosX = 6;
    curPosY = 2;
    // type = rand.nextInt(4)+1;
    type = 4;
	}
// ========================================================
//    Move
// ========================================================
	public void move(int i) {
		curPosX += i;
	}
// ========================================================
//    Down
// ========================================================
	public void dropDown() {
		curPosY += 1;
	}
// ========================================================
//    Update
// ========================================================
	public void update() {
    int x = 0;
    int y = 0;
    for (int i = 0; i < 23; i++) {
      for (int j = 0; j < 12; j++) {
        if (mapMove[i][j] == '3'){
          x = i;
          y = j;
        }
        System.out.print(mapMove[i][j]);
        mapMove[x][y] = '0';
      }
      System.out.print("\n");
    }
    System.out.println("\n"+curPosX+" :X\t"+curPosY+" :Y\t"+type+" :TYPE\t"+check+" :ARRAY");
	}
// ========================================================
//    Clear Row
// ========================================================
	public void clearRow(Graphics g) {
    int row = 0;
		for (int i = 0; i < 23; i++) {
      for (int j = 1; j < 11; j++) {
        if (mapMove[i][j] == '1') {
          row += 1;
          if (row == 10) {
            score += 100;
            for (int k = 1; k < 11; k++) {
              mapMove[i][k] = '0';
            }
          }
        }
      }
      row = 0;
    }
	}
// ========================================================
//    Collision Wall
// ========================================================
	public char collisionWall() {
		for (int i = 0; i < 23; i++) {
      for (int j = 0; j < 12; j++) {
        if (mapMove[i][j] == '3') {
          if (mapMove[i][j-1] == '2') {
            return '2';
          }
          else if (mapMove[i][j+1] == '2'){
            return '3';
          }
        }
      }
    }
    if (curPosX > 1 && curPosX < 10 ) {
      return '1';
    }
    else {
      if (curPosX == 1) {
        return '2'; // Can go Right
      }
      else {
        return '3'; // Can go Left
      }
    }
	}
// ========================================================
//    Collision Block
// ========================================================
	public char collisionBlock() {
    check = new ArrayList<Integer>();
    for (int i = 0; i < check.size(); i++) {
      System.out.println(check.get(i)+"\t PRINT ARRAY");
    }
		for (int i = 0; i < 23; i++) {
      for (int j = 0; j < 12; j++) {
        if (mapMove[i][j] == '3'){
          if (mapMove[i+1][j] == '1' || mapMove[i+1][j] == '2') {
            return '1'; // Found Block
          }
          if (mapMove[curPosY][curPosX] == '1' || mapMove[curPosY][curPosX] == '2') {
            return '1'; // Found Block
          }
          else {
            check.add(1);
            return '2'; // Not Found Block
          }
        }
      }
    }
    if (true) {
      return '3';
    }
    else {
      return '3';
    }
	}

// ========================================================
//    Draw Piece
// ========================================================
	private void drawPiece(int x, int y, int type) {
    if (type == 1) {
      mapMove[y][x] = '3';
    }
    else if (type == 2) {
      mapMove[y][x] = '3';
      mapMove[y][x-1] = '3';
    }
    else if (type == 3) {
      mapMove[y][x] = '3';
      mapMove[y][x-1] = '3';
      mapMove[y-1][x] = '3';
    }
    else if (type == 4) {
      mapMove[y][x] = '3';
      mapMove[y-1][x-1] = '3';
      mapMove[y-1][x+1] = '3';
      mapMove[y-1][x] = '3';
    }
	}
// ========================================================

// ========================================================
//    Set Piece On Screen
// ========================================================
	private void fixPiece(Graphics g, int x, int y) {
		for (int i = 0; i < 23; i++) {
      for (int j = 0; j < 12; j++) {
        if(mapMove[i][j] == '1') {
      		g.setColor(Color.RED);
          g.fillRect(j*26, i*26, sizeByPieceX, sizeByPieceY);
        }
        if (mapMove[i][j] == '3') {
      		g.setColor(Color.RED);
          g.fillRect(j*26, i*26, sizeByPieceX, sizeByPieceY);
        }
      }
    }
	}
// ========================================================
//    Key Listener
// ========================================================
  private void formKeyPressed(KeyEvent evt) {
    if (evt.getKeyCode() == evt.VK_RIGHT) {
      // Do Something
      if (running && !pause && (collisionWall() == '1' || collisionWall() == '2')) {
        move(+1);
      }
    }
    else if (evt.getKeyCode() == evt.VK_LEFT) {
      // Do Something
      if (running && !pause && (collisionWall() == '1' || collisionWall() == '3')) {
        move(-1);
      }
    }
    else if (evt.getKeyCode() == evt.VK_UP) {
      // Do Something
      if (running && !pause) {
      }
    }
  }
// ========================================================
//    Make Screen
// ========================================================
  private void makeFrameToScreen(Graphics g) {
    screen = createImage(screenx,screeny);
    gr = screen.getGraphics();
    gr.drawImage(bg.getImage(), 0, 0, null);
    // gr.drawImage(bg.getImage(), 0, 0, null);
    loadWall(gr);
    if (collisionBlock() == '1') {
      if (type == 1) {
        mapMove[curPosY-1][curPosX] = '1';
      }
      else if (type == 2) {
        mapMove[curPosY-1][curPosX] = '1';
        mapMove[curPosY-1][curPosX-1] = '1';
      }
      else if (type == 3) {
        mapMove[curPosY-1][curPosX] = '1';
        mapMove[curPosY-1][curPosX-1] = '1';
        mapMove[curPosY-2][curPosX] = '1';
      }
      else if (type == 4) {
        mapMove[curPosY-2][curPosX] = '1';
        mapMove[curPosY-2][curPosX-1] = '1';
        mapMove[curPosY-2][curPosX+1] = '1';
        mapMove[curPosY-1][curPosX] = '1';
      }
      newPiece();
      clearRow(gr);
    }
    update();
    drawPiece(curPosX, curPosY, type);
    dropDown();
    fixPiece(gr, curPosX, curPosY);
    gr.drawString(score+"", 50, 50);
    g.drawImage(screen, 0, 0, null);
  }
// ========================================================
//    Override
// ========================================================
  @Override
  public void paintComponent(Graphics g) {
    makeFrameToScreen(g);
  }

  @Override
  public void run() {
    while (running) {
      try {
        Thread.sleep(200);
        repaint();
      }
      catch (Exception e) {
        System.out.println (e.getMessage());
      }
    }
  }
} // Game
